var h1 = $(window).height();
$('.bg-image').css({'height' : h1 });